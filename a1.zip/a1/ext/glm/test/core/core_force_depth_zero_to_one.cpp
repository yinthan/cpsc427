#define GLM_FORCE_DEPTH_ZERO_TO_ONE

#include <glm/glm.hpp>
#include <glm/ext.hpp>

int main()
{
	int Error = 0;

	return Error;
}

