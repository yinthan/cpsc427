name: Ethan Song
student number: 39025374

# cpsc427
