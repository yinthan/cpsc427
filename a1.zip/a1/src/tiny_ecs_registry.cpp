#include "tiny_ecs_registry.hpp"

ECSRegistry registry;